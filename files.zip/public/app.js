// feed client logic (supports login session, posts, reactions, comments)
const feedEl = document.getElementById('feed');
const sessionEl = document.getElementById('session');
const composerSection = document.getElementById('composerSection');
const postAuthorInput = document.getElementById('postAuthor');
const postContent = document.getElementById('postContent');
const postBtn = document.getElementById('postBtn');
const profileName = document.getElementById('profileName');
const logoutBtn = document.getElementById('logout');

function escapeHtml(s=''){ return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function timeAgo(iso){ const diff = Date.now() - new Date(iso).getTime(); const mins = Math.floor(diff/60000); if(mins<1) return 'just now'; if(mins<60) return `${mins}m`; const hrs=Math.floor(mins/60); if(hrs<24) return `${hrs}h`; const days=Math.floor(hrs/24); return `${days}d`; }

async function fetchMe(){ const res = await fetch('/api/me'); return res.ok ? await res.json() : { user: null }; }

async function fetchPosts(){ const res = await fetch('/api/posts'); const body = await res.json(); renderPosts(body.posts||[], body.hiddenAuthors||[]); }

function renderPosts(posts, hiddenAuthors){
  feedEl.innerHTML = '';
  hiddenAuthors.forEach(author => {
    const lock = document.createElement('div');
    lock.className = 'locked-card card';
    lock.innerHTML = `<strong>${escapeHtml(author)}</strong>'s post is hidden<br/><div class="small">Log in to see ${escapeHtml(author)}'s post</div><div style="margin-top:8px"><button id="goLogin" class="primary">Log in</button></div>`;
    feedEl.appendChild(lock);
    lock.querySelector('#goLogin').onclick = () => window.location.href = '/';
  });

  posts.forEach(p => {
    const el = document.createElement('article');
    el.className = 'post card';
    el.innerHTML = `
      <div class="meta">
        <div><strong>${escapeHtml(p.author)}</strong> · <span class="small">${timeAgo(p.createdAt)}</span></div>
        <div class="small">${(p.reactions?.like||0)} likes · ${(p.reactions?.love||0)} loves</div>
      </div>
      <div class="content">${escapeHtml(p.content)}</div>
      <div class="actions">
        <button class="action-btn react-btn" data-id="${p.id}" data-type="like">Like</button>
        <button class="action-btn react-btn" data-id="${p.id}" data-type="love">Love</button>
        <button class="action-btn comment-toggle" data-id="${p.id}">Comment</button>
      </div>
      <div class="comments" id="comments-${p.id}">
        ${(p.comments||[]).map(c => `<div class="comment"><span class="author">${escapeHtml(c.author)}</span><span>${escapeHtml(c.text)}</span></div>`).join('')}
        <div class="add-comment" style="margin-top:8px">
          <input placeholder="Your name" class="c-author" data-id="${p.id}" />
          <input placeholder="Write a comment..." class="c-text" data-id="${p.id}" />
          <button class="action-btn c-submit" data-id="${p.id}">Add</button>
        </div>
      </div>
    `;
    feedEl.appendChild(el);
  });

  // wire up reaction buttons
  document.querySelectorAll('.react-btn').forEach(btn => {
    btn.onclick = async () => {
      const id = btn.dataset.id, type = btn.dataset.type;
      await fetch(`/api/posts/${id}/reaction`, {
        method: 'POST',
        headers: { 'Content-Type':'application/json' },
        body: JSON.stringify({ type })
      });
      await refresh();
    };
  });

  // comments
  document.querySelectorAll('.c-submit').forEach(btn => {
    btn.onclick = async () => {
      const id = btn.dataset.id;
      const author = document.querySelector(`.c-author[data-id="${id}"]`).value.trim();
      const text = document.querySelector(`.c-text[data-id="${id}"]`).value.trim();
      if(!author||!text) return alert('Enter name and comment');
      await fetch(`/api/posts/${id}/comment`, {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ author, text })
      });
      await refresh();
    };
  });
}

async function refresh(){
  await fetchSession();
  await fetchPosts();
}

async function fetchSession(){
  const me = await fetchMe();
  const user = me.user ? me.user.username : null;
  if(user){
    sessionEl.innerHTML = `Logged in as <strong>${escapeHtml(user)}</strong>`;
    composerSection.style.display = 'block';
    postAuthorInput.value = user;
    profileName.textContent = user;
    logoutBtn.style.display = 'inline-block';
    logoutBtn.onclick = async () => { await fetch('/api/logout', { method:'POST' }); window.location.href = '/'; };
  } else {
    sessionEl.innerHTML = `Viewing as guest — <a href="/">Log in</a>`;
    composerSection.style.display = 'none';
    profileName.textContent = 'Guest';
    logoutBtn.style.display = 'none';
  }
}

postBtn && postBtn.addEventListener('click', async () => {
  const content = postContent.value.trim();
  if(!content) return alert('Enter post content');
  const res = await fetch('/api/posts', {
    method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ content })
  });
  if(res.status === 401) return alert('You must be logged in to post');
  postContent.value = '';
  await refresh();
});

// initial
refresh();